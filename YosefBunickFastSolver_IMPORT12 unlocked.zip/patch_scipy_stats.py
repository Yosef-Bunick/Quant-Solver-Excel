#!/usr/bin/env python3
# patch_scipy_stats.py
#
# Fixes the PyInstaller-on-Python-3.12 crash:
#     File "scipy/stats/_distn_infrastructure.py", line ~369, in <module>
#         del obj
#     NameError: name 'obj' is not defined
#
# Under PyInstaller's frozen loader, the for-loop comprehension variable
# 'obj' is never bound in module globals. BOTH references to 'obj' crash:
#   1. exec('del ' + obj) — resolving 'obj' for string concatenation
#   2. del obj          — the bare delete after the loop
#
# This wraps the ENTIRE cleanup block in try/except NameError.
#
# USAGE (run once, in the SAME Python env you build with):
#   python patch_scipy_stats.py
#   python 11_build_exe.py
#
# Idempotent: running it again detects the patch and does nothing.
# Reversible: a .bak backup is written next to the patched file.

import shutil
import sys
from pathlib import Path

MARKER = "# [FASTSOLVER PATCH] entire block guarded"


def find_target():
    try:
        import scipy.stats._distn_infrastructure as m
    except Exception as e:
        print(f"Could not import scipy.stats._distn_infrastructure: {e}",
              file=sys.stderr)
        sys.exit(1)
    p = Path(m.__file__)
    if not p.is_file():
        print(f"Resolved path is not a file: {p}", file=sys.stderr)
        sys.exit(1)
    return p


def main():
    target = find_target()
    src = target.read_text(encoding="utf-8")

    if MARKER in src:
        print(f"Already patched: {target}")
        return

    # Verify the expected original block exists
    needle = "for obj in [s for s in dir() if s.startswith('_doc_')]:"
    if needle not in src:
        print("Expected scipy cleanup block not found. scipy version may "
              "differ; aborting WITHOUT changes so nothing is corrupted.\n"
              f"  File: {target}\n"
              "  Fallback: build under Python 3.11 instead.",
              file=sys.stderr)
        sys.exit(2)

    old_block = (
        "# clean up all the separate docstring elements, we do not need them anymore\n"
        "for obj in [s for s in dir() if s.startswith('_doc_')]:\n"
        "    exec('del ' + obj)\n"
        "del obj\n"
    )
    new_block = (
        "# clean up all the separate docstring elements, we do not need them anymore\n"
        f"{MARKER} — frozen loader may not bind comprehension variable\n"
        "# 'obj' in module globals, so BOTH exec('del ' + obj) AND del obj\n"
        "# can raise NameError.\n"
        "try:\n"
        "    for obj in [s for s in dir() if s.startswith('_doc_')]:\n"
        "        exec('del ' + obj)\n"
        "    del obj\n"
        "except NameError:\n"
        "    pass\n"
    )

    if old_block not in src:
        print("Found the loop but not the exact block layout. "
              "scipy source differs from expected. Not editing blindly.\n"
              f"  File: {target}\n"
              "  Fallback: build under Python 3.11 instead.",
              file=sys.stderr)
        sys.exit(3)

    backup = target.with_suffix(target.suffix + ".bak")
    if not backup.exists():
        shutil.copy2(target, backup)
        print(f"Backup written: {backup}")

    src = src.replace(old_block, new_block, 1)
    target.write_text(src, encoding="utf-8")
    print(f"Patched: {target}")
    print("Now run: python 11_build_exe.py")


if __name__ == "__main__":
    main()
