from __future__ import annotations
import re, math, pickle, pathlib
from typing import Any, Dict, List, Optional, Set

try:
    import xlsxparser as _cpp
    _CPP_AVAILABLE = True
except ImportError:
    _CPP_AVAILABLE = False

try:
    from excel_functions_80 import EXACT_REGISTRY_80 as _REGISTRY
except ImportError:
    _REGISTRY = {}

# FIX 8: compile regexes at module level with correct raw strings
_REF_RE = re.compile(
    r"(?:'(?:[^']|'')*'!|([A-Za-z_]\w*)!)?\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6})\b",
    re.IGNORECASE,
)
_FN_RE = re.compile(r"\b([A-Z][A-Z0-9_.]*)\s*\(", re.IGNORECASE)

# Range ref regex with range endpoint capture — compiled ONCE at module level
_RANGE_RE = re.compile(
    r"(?:'(?:[^']|'')*'!|([A-Za-z_]\w*)!)?\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6})"
    r"(?::\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6}))?",
    re.IGNORECASE,
)

# Column letter <-> index helpers (used by range expansion)
def _col_to_idx(col):
    v = 0
    for c in col.upper():
        v = v * 26 + (ord(c) - ord('A') + 1)
    return v


def _idx_to_col(idx):
    s = ""
    while idx > 0:
        s = chr(ord('A') + (idx - 1) % 26) + s
        idx = (idx - 1) // 26
    return s


def _try_float(s):
    try:    return float(s)
    except: return s


def _same_numeric_value(a, b):
    """Return True for equal numeric values even when types differ (float vs numpy scalar).

    Keep this conservative: only numeric-equal values are skipped. Formula cells
    are never skipped because writing a literal over a formula must remove the
    formula even when the cached value happens to match.
    """
    if a is None or b is None:
        return a is b
    try:
        af, bf = float(a), float(b)
        return af == bf or (af != af and bf != bf)
    except Exception:
        return False


_MATH_NAMES = (
    "sqrt", "exp", "log", "log10", "sin", "cos", "tan",
    "pi", "e", "floor", "ceil", "fabs", "pow",
    "log2", "log1p", "expm1", "hypot", "atan", "atan2",
    "asin", "acos", "sinh", "cosh", "tanh",
    "degrees", "radians", "erf", "erfc", "gamma", "lgamma",
)


class _CellProxy:
    __slots__ = ("_fc", "_addr", "formula")
    def __init__(self, fc, addr):
        self._fc = fc
        self._addr = addr
        self.formula = fc._formulas.get(addr)

    @property
    def value(self):
        return self._fc._values.get(self._addr)

    @value.setter
    def value(self, v):
        if v is None:
            self._fc._dirty.add(self._addr)
        else:
            self._fc._values[self._addr] = v


class _CellMap:
    def __init__(self, fc):
        self._fc = fc

    def get(self, addr, default=None):
        a = FastExcelCompiler._norm(addr)
        if a in self._fc._values or a in self._fc._formulas:
            return _CellProxy(self._fc, a)
        return default

    def keys(self):
        """All known cell addresses (formulas + values)."""
        return set(self._fc._formulas) | set(self._fc._values)

    def __len__(self):
        return len(self.keys())

    def __contains__(self, addr):
        a = FastExcelCompiler._norm(addr)
        return a in self._fc._formulas or a in self._fc._values

    def __iter__(self):
        return iter(self.keys())


class FastExcelCompiler:
    def __init__(self, filename: str, eager: bool = True):
        if not _CPP_AVAILABLE:
            raise ImportError("xlsxparser not found. Run: python build_parser.py")
        self._filename   = filename
        self._values     = {}
        self._formulas   = {}
        self._topo       = []
        self._rdeps      = {}
        self._dirty      = set()
        self._fns        = dict(_REGISTRY)
        self._topo_index = {}
        self.cell_map    = _CellMap(self)
        self._fastsolver_name_maps = None
        self._loaded = False
        self._load(filename)
        self._precompile()
        if eager:
            self._eval_all()

    def _load(self, path):
        wb = _cpp.parse(path)
        err = wb.get("error", "")
        if err:
            raise RuntimeError("FastExcelCompiler: " + err)
        self._topo = [self._norm(a) for a in wb["topo_order"]]
        self._topo_index = {a: i for i, a in enumerate(self._topo)}
        for addr, info in wb["cells"].items():
            a = self._norm(addr)
            if info["is_formula"]:
                self._formulas[a] = info["formula"]
                # Don't store cached value — formulas must be evaluated
                # (lazy eval skips non‑None values; stale cache would prevent eval)
                self._values[a] = None
            else:
                self._values[a] = _try_float(info["value"])
        for frm, to in wb["edges"]:
            fn, tn = self._norm(frm), self._norm(to)
            self._rdeps.setdefault(tn, set()).add(fn)
        self._loaded = True

    @classmethod
    def from_graph_dict(cls, graph_dict, filename=""):
        """Create FastExcelCompiler from a pre-parsed graph dict.

        Avoids re-parsing the xlsx — used by subprocesses that receive
        a shared graph from the parent process.
        """
        fc = cls.__new__(cls)
        fc._filename   = filename or graph_dict.get("_filename", "")
        fc._values     = {}
        fc._formulas   = {}
        fc._topo       = []
        fc._rdeps      = {}
        fc._dirty      = set()
        fc._fns        = dict(_REGISTRY)
        fc._fastsolver_name_maps = None

        fc._topo = [cls._norm(a) for a in graph_dict["topo_order"]]
        fc._topo_index = {a: i for i, a in enumerate(fc._topo)}
        for addr, info in graph_dict["cells"].items():
            a = cls._norm(addr)
            if info["is_formula"]:
                fc._formulas[a] = info["formula"]
                fc._values[a]   = _try_float(info["value"])
            else:
                fc._values[a] = _try_float(info["value"])
        for frm, to in graph_dict.get("edges", []):
            fn, tn = cls._norm(frm), cls._norm(to)
            fc._rdeps.setdefault(tn, set()).add(fn)

        fc.cell_map = _CellMap(fc)
        fc._loaded = True
        fc._precompile()
        # Don't eval_all() here — the wrapper handles initial evaluation
        return fc

    def graph_to_dict(self):
        """Return the raw graph dict suitable for pickle/sharing."""
        return _cpp.parse(self._filename)

    def _clear_formula_execution_caches(self):
        if hasattr(self, "_dirty_block_cache"):
            self._dirty_block_cache.clear()
        if hasattr(self, "_dirty_plan_cache"):
            self._dirty_plan_cache.clear()
        if hasattr(self, "_dep_closure_cache"):
            self._dep_closure_cache.clear()

    def set_values_bulk(self, addr_value_pairs):
        """Set many input cells and expand the dirty dependency closure once.

        This is semantics-equivalent to calling set_value() for every pair and
        then evaluating, because formulas are not evaluated between writes in
        the solver hot path. It avoids repeating the same downstream graph walk
        for every variable on every objective call.
        """
        roots = []
        norm = self._norm
        values = self._values
        formulas = self._formulas
        compiled_exists = hasattr(self, "_compiled")
        for addr, value in addr_value_pairs:
            a = norm(addr)
            if isinstance(value, str) and value.startswith("="):
                formulas[a] = value[1:].strip()
                values[a] = float("nan")
                if compiled_exists:
                    self._compile_addr(a)
                    self._clear_formula_execution_caches()
                roots.append(a)
            else:
                current = values.get(a)
                if a not in formulas and _same_numeric_value(current, value):
                    continue
                values[a] = value
                if formulas.pop(a, None) is not None and compiled_exists:
                    self._translated.pop(a, None)
                    self._compiled.pop(a, None)
                    self._clear_formula_execution_caches()
                roots.append(a)
        if not roots:
            return
        dirty = self._dirty
        rdeps = self._rdeps
        cache = getattr(self, "_dep_closure_cache", None)
        if cache is None:
            self._dep_closure_cache = cache = {}
        key = tuple(roots)
        hit = cache.get(key)
        if hit is not None:
            dirty.update(hit)
            return
        seen = set()
        stack = list(roots)
        while stack:
            a = stack.pop()
            if a not in seen:
                seen.add(a)
                stack.extend(rdeps.get(a, ()))
        cache[key] = tuple(seen)
        dirty.update(seen)

    def set_value(self, addr, value):
        a = self._norm(addr)
        if isinstance(value, str) and value.startswith("="):
            # Bridge eval_ref() creates temporary formula cells. Compile those
            # immediately so cached formula refs do not translate on every read.
            self._formulas[a] = value[1:].strip()
            self._values[a]   = float("nan")
            if hasattr(self, "_compiled"):
                self._compile_addr(a)
                self._clear_formula_execution_caches()
        else:
            # Skip true no-op writes, including float vs numpy.float64 equality.
            # Do not skip formula cells: setting a literal must remove the formula.
            current = self._values.get(a)
            if a not in self._formulas and _same_numeric_value(current, value):
                return
            self._values[a] = value
            if self._formulas.pop(a, None) is not None and hasattr(self, "_compiled"):
                self._translated.pop(a, None)
                self._compiled.pop(a, None)
                self._clear_formula_execution_caches()
        self._mark_dirty(a)

    def evaluate(self, addr):
        a = self._norm(addr)
        if self._dirty:
            self._eval_dirty()
        v = self._values.get(a)
        if v is None and a in self._formulas:
            # Lazy eval: compute un-evaluated formulas on first access.
            # Walks topo order up to this cell, evaluating any None formulas.
            try:
                for t in self._topo:
                    if self._values.get(t) is not None:
                        continue
                    if t in self._formulas:
                        self._values[t] = self._eval_formula(t)
                    if t == a:
                        break
                v = self._values.get(a)
            except Exception:
                v = 0.0
        if v is None:
            return 0.0
        return v

    def _eval_all(self):
        n_total = 0
        n_fail = 0
        for addr in self._topo:
            if addr in self._formulas:
                n_total += 1
                self._values[addr] = self._eval_formula(addr)
        # Diagnostics are off by default; never write files in normal runs.
        try:
            import os as _os
            if not _os.environ.get("FAST_COMPILER_DEBUG"):
                return
            log = _os.path.join(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")),
                                "fc_eval_all.log")
            nz = sum(1 for a in self._formulas
                     if self._values.get(a) is not None
                     and not (isinstance(self._values[a], float)
                              and self._values[a] != self._values[a])
                     and self._values.get(a, 0) != 0)
            nnan = sum(1 for a in self._formulas
                       if isinstance(self._values.get(a), float)
                       and self._values[a] != self._values[a])
            nzero = n_total - nz - nnan
            with open(log, "w", encoding="utf-8") as fh:
                fh.write(f"Evaluated {n_total} formulas\n")
                fh.write(f"Non-zero: {nz}, Zero: {nzero}, NaN: {nnan}\n")
                fh.write(f"_REGISTRY size: {len(_REGISTRY)}\n")
        except Exception:
            pass

    def _mark_dirty(self, addr):
        cache = getattr(self, "_dep_closure_cache", None)
        if cache is None:
            self._dep_closure_cache = cache = {}
        hit = cache.get(addr)
        if hit is not None:
            self._dirty.update(hit)
            return
        seen = set()
        stack = [addr]
        rdeps = self._rdeps
        while stack:
            a = stack.pop()
            if a not in seen:
                seen.add(a)
                stack.extend(rdeps.get(a, ()))
        cache[addr] = tuple(seen)
        self._dirty.update(seen)

    def _eval_dirty(self):
        if not self._dirty:
            return
        # Same semantics as V3: use the already-expanded dirty closure and
        # evaluate dirty formulas in topo order. Speed win: cache the sorted
        # dirty plan and compile it into one Python function.
        dirty_key = frozenset(self._dirty)
        plan_cache = getattr(self, "_dirty_plan_cache", None)
        if plan_cache is None:
            self._dirty_plan_cache = plan_cache = {}
        plan = plan_cache.get(dirty_key)
        if plan is None:
            dirty_formulas = [a for a in self._dirty if a in self._formulas]
            if dirty_formulas:
                dirty_formulas.sort(key=lambda a: self._topo_index.get(a, 0))
                dirty_formulas = tuple(dirty_formulas)
                block = self._get_dirty_block(dirty_formulas)
            else:
                dirty_formulas = ()
                block = None
            plan = (dirty_formulas, block)
            # Cap avoids unbounded growth if an optimizer probes many distinct
            # formula/temp-cell combinations.
            if len(plan_cache) > 256:
                plan_cache.clear()
            plan_cache[dirty_key] = plan
        dirty_formulas, block = plan
        if dirty_formulas:
            if block is not None:
                block()
            else:
                values = self._values
                compiled_map = self._compiled
                env = self._env
                eval_formula = self._eval_formula
                for addr in dirty_formulas:
                    code = compiled_map.get(addr)
                    if code is not None:
                        try:
                            values[addr] = eval(code, env)
                        except Exception:
                            values[addr] = float("nan")
                    else:
                        values[addr] = eval_formula(addr)
        self._dirty.clear()

    def _get_dirty_block(self, addrs):
        """Return a cached function that evaluates a specific topo-ordered
        formula list with V3 semantics: each formula gets its own try/except
        and writes NaN on formula error. This removes millions of eval() calls
        while preserving formula order and Excel-style _cv coercion.
        """
        cache = getattr(self, "_dirty_block_cache", None)
        if cache is None:
            self._dirty_block_cache = cache = {}
        hit = cache.get(addrs)
        if hit is not None:
            return hit

        compiled = self._compiled
        translated = self._translated
        lines = ["def _dirty_block(_V=_V, _g=_g, _cv=_cv, _fns=_fns, nan=nan, inf=inf, Exception=Exception, abs=abs, max=max, min=min, round=round, sum=sum, len=len, list=list, range=range, sqrt=sqrt, exp=exp, log=log, log10=log10, sin=sin, cos=cos, tan=tan, pi=pi, e=e, floor=floor, ceil=ceil, fabs=fabs, pow=pow, log2=log2, log1p=log1p, expm1=expm1, hypot=hypot, atan=atan, atan2=atan2, asin=asin, acos=acos, sinh=sinh, cosh=cosh, tanh=tanh, degrees=degrees, radians=radians, erf=erf, erfc=erfc, gamma=gamma, lgamma=lgamma):"]
        n = 0
        for addr in addrs:
            if compiled.get(addr) is None:
                cache[addrs] = None
                return None
            expr = translated.get(addr)
            if not expr:
                cache[addrs] = None
                return None
            # Keep errors local to the cell, exactly like the old per-formula loop.
            lines.append("    try:")
            lines.append(f"        _V[{addr!r}] = ({expr})")
            lines.append("    except Exception:")
            lines.append(f"        _V[{addr!r}] = nan")
            n += 1
        if n == 0:
            cache[addrs] = None
            return None
        src = "\n".join(lines) + "\n"
        ns = {}
        try:
            exec(compile(src, "<fast_compiler_dirty_block>", "exec"), self._env, ns)
            fn = ns.get("_dirty_block")
        except Exception:
            fn = None
        cache[addrs] = fn
        return fn

    def _eval_formula(self, addr):
        compiled = self._compiled.get(addr) if hasattr(self, '_compiled') else None
        if compiled is None and hasattr(self, "_compiled"):
            compiled = self._compile_addr(addr)
        if compiled is not None:
            try:
                return eval(compiled, self._env)
            except Exception:
                # Match the old non-compiled _run() behavior: formula errors become
                # NaN, not stale previous values. Stale values can make the solver
                # accept an invalid probe and converge to the wrong answer.
                return float("nan")
        # Fallback: translate+runtime eval.
        formula = self._formulas[addr]
        sheet = addr.split("!")[0].strip("'") if "!" in addr else "Sheet1"
        try:
            translated = self._translate(formula, sheet)
            return self._run(translated)
        except Exception:
            return float("nan")

    def _translate(self, formula, sheet):
        formula = str(formula).strip()
        if formula.startswith("="):
            formula = formula[1:].strip()

        def sub_ref(m):
            full = m.group(0)
            col1, row1 = m.group(2).upper(), m.group(3)
            col2, row2 = m.group(4), m.group(5)  # None if single cell
            rs = sheet
            bang = full.find("!")
            if bang != -1:
                rs = full[:bang].strip().strip("'")

            if col2 is None:
                # Single cell: emit stable _cv(_V.get(...)) for type safety
                addr = self._norm(rs + "!" + col1 + row1)
                return f"_cv(_g({addr!r}, 0.0))"
            else:
                # Range: expand once into list of _cv(_V.get(...)) calls
                col2 = col2.upper()
                c1, c2 = _col_to_idx(col1), _col_to_idx(col2)
                r1, r2 = int(row1), int(row2)
                if c1 > c2: c1, c2 = c2, c1
                if r1 > r2: r1, r2 = r2, r1
                parts = []
                for r in range(r1, min(r2 + 1, r1 + 10000)):
                    for c in range(c1, min(c2 + 1, c1 + 100)):
                        addr = self._norm(rs + "!" + _idx_to_col(c) + str(r))
                        parts.append(f"_cv(_g({addr!r}, 0.0))")
                return "[" + ",".join(parts) + "]"

        # BUG FIX: regex now captures optional range endpoint (col2, row2)
        # FIX: require ! after unquoted sheet names so multi-letter columns (AA, AB, ...)
        # aren't eaten as sheet names. Group indices shifted +1 vs old pattern.
        # _RANGE_RE is compiled ONCE at module level — NOT per formula.
        expr = _RANGE_RE.sub(sub_ref, formula)

        def sub_fn(m):
            name = m.group(1).upper()
            if name in self._fns:
                return f"_fns[{name!r}]("
            alt = name.replace(".", "_")
            if alt in self._fns:
                return f"_fns[{alt!r}]("
            return m.group(0)

        expr = _FN_RE.sub(sub_fn, expr)

        # Fix Excel vs Python operator differences
        # ^ is XOR in Python, but exponentiation in Excel
        expr = expr.replace("^", "**")
        # #REF! is invalid syntax in Python
        expr = expr.replace("#REF!", "nan")

        return expr

    def _run(self, expr_or_code):
        try:
            return eval(expr_or_code, self._env)
        except Exception:
            return float("nan")

    def _build_env(self):
        env = {
            "__builtins__": {}, "True": True, "False": False,
            "nan": float("nan"), "inf": float("inf"), "float": float,
            "abs": abs, "max": max, "min": min, "round": round,
            "sum": sum, "len": len, "list": list, "range": range,
            "Exception": Exception,
            "_V": self._values,
            "_g": self._values.get,
            "_cv": FastExcelCompiler._cv,
            "_fns": self._fns,
        }
        for k in _MATH_NAMES:
            env[k] = getattr(math, k, 0.0)
        return env

    def _compile_addr(self, addr):
        formula = self._formulas.get(addr)
        if formula is None:
            self._translated.pop(addr, None)
            self._compiled.pop(addr, None)
            return None
        sheet = addr.split("!")[0].strip("'") if "!" in addr else "Sheet1"
        key = (sheet, formula)
        expr = self._expr_cache.get(key)
        if expr is None:
            try:
                expr = self._translate(formula, sheet)
            except Exception:
                expr = "nan"
            self._expr_cache[key] = expr
        self._translated[addr] = expr

        code = self._code_cache.get(expr)
        if code is None and expr not in self._bad_exprs:
            try:
                code = compile(expr, f"<{addr}>", "eval")
                self._code_cache[expr] = code
            except Exception:
                self._bad_exprs.add(expr)
                code = None
        self._compiled[addr] = code
        return code

    def _precompile(self):
        """Translate/compile formulas once, but preserve _cv Excel coercion semantics."""
        self._translated = {}
        self._compiled = {}
        self._expr_cache = {}
        self._code_cache = {}
        self._bad_exprs = set()
        self._dirty_block_cache = {}
        self._dirty_plan_cache = {}
        self._dep_closure_cache = {}
        self._env = self._build_env()
        for addr in self._formulas:
            self._compile_addr(addr)

    @staticmethod
    def _cv(v):
        """Convert cell value for eval namespace — handles None, bool, strings.

        Optimized for the common case where workbook cells are already Python
        floats, while preserving the V3 coercion behavior for blanks/errors/text.
        """
        tv = type(v)
        if tv is float:
            return v
        if tv is int:
            return float(v)
        if v is None:
            return 0.0
        if tv is bool:
            return 1.0 if v else 0.0
        if isinstance(v, (int, float)):
            return float(v)
        if tv is str:
            if v.startswith("#"):
                return float("nan")
            try:
                return float(v)
            except ValueError:
                return 0.0
        try:
            return float(v)
        except Exception:
            return 0.0

    @staticmethod
    def _norm(addr):
        # FIX 9: always strip $ so Sheet1!$B$4 == Sheet1!B4
        if "!" not in addr:
            return addr.replace("$", "").upper()
        sheet, ref = addr.rsplit("!", 1)
        sheet = sheet.strip().strip("'")
        ref   = ref.replace("$", "").upper()
        return ("'" + sheet + "'!" + ref) if " " in sheet else (sheet + "!" + ref)

    # FIX 10+11: to_file / from_file so bridge cache logic works unchanged
    def to_file(self, base_name, file_types=("pkl",)):
        if "pkl" in file_types:
            pkl = (base_name if base_name.endswith(".pkl") else base_name + ".pkl")
            try:
                with open(pkl, "wb") as f:
                    pickle.dump({"filename": self._filename}, f)
            except Exception:
                pass

    def trim_graph(self, input_addrs=None, output_addrs=None):
        """Stub: C++ backend loads fast enough that subgraph pruning is
        not needed. The wrapper calls this; we accept and no-op."""
        pass

    @classmethod
    def from_file(cls, path):
        pkl = path if path.endswith(".pkl") else path + ".pkl"
        try:
            with open(pkl, "rb") as f:
                data = pickle.load(f)
            fn = data.get("filename", "")
            if fn and pathlib.Path(fn).exists():
                return cls(fn)
        except Exception:
            pass
        raise FileNotFoundError("FastExcelCompiler.from_file: cannot reload " + path)


ExcelCompiler = FastExcelCompiler

