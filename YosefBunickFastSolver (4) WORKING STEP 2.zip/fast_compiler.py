from __future__ import annotations
import re, math, pickle, pathlib
from typing import Any, Dict, List, Optional, Set

try:
    import xlsxparser as _cpp
    _CPP_AVAILABLE = True
except ImportError:
    _CPP_AVAILABLE = False

try:
    from excel_functions_80 import EXACT_REGISTRY_80 as _REGISTRY
except ImportError:
    _REGISTRY = {}

# FIX 8: compile regexes at module level with correct raw strings
_REF_RE = re.compile(
    r"(?:'(?:[^']|'')*'!|([A-Za-z_]\w*)!)?\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6})\b",
    re.IGNORECASE,
)
_FN_RE = re.compile(r"\b([A-Z][A-Z0-9_.]*)\s*\(", re.IGNORECASE)

# Perf counter
_dirty_call_count = 0

# Range ref regex with range endpoint capture — compiled ONCE at module level
_RANGE_RE = re.compile(
    r"(?:'(?:[^']|'')*'!|([A-Za-z_]\w*)!)?\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6})"
    r"(?::\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6}))?",
    re.IGNORECASE,
)

# Column letter <-> index helpers (used by range expansion)
def _col_to_idx(col):
    v = 0
    for c in col.upper():
        v = v * 26 + (ord(c) - ord('A') + 1)
    return v


def _idx_to_col(idx):
    s = ""
    while idx > 0:
        s = chr(ord('A') + (idx - 1) % 26) + s
        idx = (idx - 1) // 26
    return s


def _try_float(s):
    try:    return float(s)
    except: return s


class _CellProxy:
    __slots__ = ("_fc", "_addr", "formula")
    def __init__(self, fc, addr):
        self._fc = fc
        self._addr = addr
        self.formula = fc._formulas.get(addr)

    @property
    def value(self):
        return self._fc._values.get(self._addr)

    @value.setter
    def value(self, v):
        if v is None:
            self._fc._dirty.add(self._addr)
        else:
            self._fc._values[self._addr] = v


class _CellMap:
    def __init__(self, fc):
        self._fc = fc

    def get(self, addr, default=None):
        a = FastExcelCompiler._norm(addr)
        if a in self._fc._values or a in self._fc._formulas:
            return _CellProxy(self._fc, a)
        return default

    def keys(self):
        """All known cell addresses (formulas + values)."""
        return set(self._fc._formulas) | set(self._fc._values)

    def __len__(self):
        return len(self.keys())

    def __contains__(self, addr):
        a = FastExcelCompiler._norm(addr)
        return a in self._fc._formulas or a in self._fc._values

    def __iter__(self):
        return iter(self.keys())


class FastExcelCompiler:
    def __init__(self, filename: str, eager: bool = True):
        if not _CPP_AVAILABLE:
            raise ImportError("xlsxparser not found. Run: python build_parser.py")
        self._filename   = filename
        self._values     = {}
        self._formulas   = {}
        self._topo       = []
        self._rdeps      = {}
        self._dirty      = set()
        self._fn_locals  = {}
        self._topo_index = {}
        self.cell_map    = _CellMap(self)
        self._fastsolver_name_maps = None
        self._loaded = False
        self._load(filename)
        if eager:
            self._eval_all()

    def _load(self, path):
        wb = _cpp.parse(path)
        err = wb.get("error", "")
        if err:
            raise RuntimeError("FastExcelCompiler: " + err)
        self._topo = [self._norm(a) for a in wb["topo_order"]]
        self._topo_index = {a: i for i, a in enumerate(self._topo)}
        for addr, info in wb["cells"].items():
            a = self._norm(addr)
            if info["is_formula"]:
                self._formulas[a] = info["formula"]
                # Don't store cached value — formulas must be evaluated
                # (lazy eval skips non‑None values; stale cache would prevent eval)
                self._values[a] = None
            else:
                self._values[a] = _try_float(info["value"])
        for frm, to in wb["edges"]:
            fn, tn = self._norm(frm), self._norm(to)
            self._rdeps.setdefault(tn, set()).add(fn)
        self._loaded = True

    @classmethod
    def from_graph_dict(cls, graph_dict, filename=""):
        """Create FastExcelCompiler from a pre-parsed graph dict.

        Avoids re-parsing the xlsx — used by subprocesses that receive
        a shared graph from the parent process.
        """
        fc = cls.__new__(cls)
        fc._filename   = filename or graph_dict.get("_filename", "")
        fc._values     = {}
        fc._formulas   = {}
        fc._topo       = []
        fc._rdeps      = {}
        fc._dirty      = set()
        fc._fn_locals  = {}
        fc._fastsolver_name_maps = None

        fc._topo = [cls._norm(a) for a in graph_dict["topo_order"]]
        fc._topo_index = {a: i for i, a in enumerate(fc._topo)}
        for addr, info in graph_dict["cells"].items():
            a = cls._norm(addr)
            if info["is_formula"]:
                fc._formulas[a] = info["formula"]
                fc._values[a]   = _try_float(info["value"])
            else:
                fc._values[a] = _try_float(info["value"])
        for frm, to in graph_dict.get("edges", []):
            fn, tn = cls._norm(frm), cls._norm(to)
            fc._rdeps.setdefault(tn, set()).add(fn)

        fc.cell_map = _CellMap(fc)
        fc._loaded = True
        # Don't eval_all() here — the wrapper handles initial evaluation
        return fc

    def graph_to_dict(self):
        """Return the raw graph dict suitable for pickle/sharing."""
        return _cpp.parse(self._filename)

    def set_value(self, addr, value):
        a = self._norm(addr)
        if isinstance(value, str) and value.startswith("="):
            self._formulas[a] = value[1:]
            self._values[a]   = float("nan")
        else:
            self._values[a] = value
            self._formulas.pop(a, None)
        self._mark_dirty(a)

    def evaluate(self, addr):
        a = self._norm(addr)
        if self._dirty:
            self._eval_dirty()
        v = self._values.get(a)
        if v is None and a in self._formulas:
            # Lazy eval: compute un-evaluated formulas on first access.
            # Walks topo order up to this cell, evaluating any None formulas.
            try:
                for t in self._topo:
                    if self._values.get(t) is not None:
                        continue
                    if t in self._formulas:
                        self._values[t] = self._eval_formula(t)
                    if t == a:
                        break
                v = self._values.get(a)
            except Exception:
                v = 0.0
        if v is None:
            return 0.0
        return v

    def _eval_all(self):
        n_total = 0
        n_fail = 0
        for addr in self._topo:
            if addr in self._formulas:
                n_total += 1
                self._values[addr] = self._eval_formula(addr)
        # Diagnostic: write summary to %TEMP%/fc_eval_all.log
        try:
            import os as _os
            log = _os.path.join(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")),
                                "fc_eval_all.log")
            nz = sum(1 for a in self._formulas
                     if self._values.get(a) is not None
                     and not (isinstance(self._values[a], float)
                              and self._values[a] != self._values[a])
                     and self._values.get(a, 0) != 0)
            nnan = sum(1 for a in self._formulas
                       if isinstance(self._values.get(a), float)
                       and self._values[a] != self._values[a])
            nzero = n_total - nz - nnan
            with open(log, "w", encoding="utf-8") as fh:
                fh.write(f"Evaluated {n_total} formulas\n")
                fh.write(f"Non-zero: {nz}, Zero: {nzero}, NaN: {nnan}\n")
                fh.write(f"_REGISTRY size: {len(_REGISTRY)}\n")
                fh.write("--- First 5 non-zero ---\n")
                cnt = 0
                for a in self._topo:
                    if a in self._formulas:
                        v = self._values.get(a)
                        if v is not None and not (isinstance(v, float) and v != v) and v != 0:
                            fh.write(f"[{a}] = {v}  |  {str(self._formulas[a])[:120]}\n")
                            cnt += 1
                            if cnt >= 5:
                                break
                fh.write("--- First 5 zero ---\n")
                cnt = 0
                for a in self._topo:
                    if a in self._formulas:
                        v = self._values.get(a)
                        if v == 0:
                            fh.write(f"[{a}] = 0.0  |  {str(self._formulas[a])[:120]}\n")
                            cnt += 1
                            if cnt >= 5:
                                break
        except Exception:
            pass

    def _mark_dirty(self, addr):
        stack = [addr]
        while stack:
            a = stack.pop()
            if a not in self._dirty:
                self._dirty.add(a)
                for dep in self._rdeps.get(a, ()):
                    stack.append(dep)

    def _eval_dirty(self):
        if not self._dirty:
            return
        ndirty = len(self._dirty)
        # Only evaluate dirty formula cells, sorted by topo order
        dirty_formulas = [a for a in self._dirty if a in self._formulas]
        if dirty_formulas:
            dirty_formulas.sort(key=lambda a: self._topo_index.get(a, 0))
            for addr in dirty_formulas:
                self._values[addr] = self._eval_formula(addr)
        self._dirty.clear()

        # PERF: log count every 200 calls
        global _dirty_call_count
        _dirty_call_count += 1
        if _dirty_call_count % 200 == 0:
            try:
                import os as _os
                log = _os.path.join(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")),
                                    "fc_perf.log")
                mode = "a" if _dirty_call_count > 200 else "w"
                with open(log, mode, encoding="utf-8") as fh:
                    fh.write(f"_eval_dirty #{_dirty_call_count}: "
                             f"dirty_total={ndirty} formulas_evaled={len(dirty_formulas)}\n")
            except Exception:
                pass

    def _eval_formula(self, addr):
        formula = self._formulas[addr]
        sheet = addr.split("!")[0].strip("'") if "!" in addr else "Sheet1"
        try:
            self._fn_locals = {}
            translated = self._translate(formula, sheet)
            result = self._run(translated)
            return result
        except Exception as e:
            _log_eval_fail(addr, formula, e)
            return self._values.get(addr, 0.0)

    def _translate(self, formula, sheet):
        def sub_ref(m):
            full = m.group(0)
            col1, row1 = m.group(2).upper(), m.group(3)
            col2, row2 = m.group(4), m.group(5)  # None if single cell
            rs = sheet
            bang = full.find("!")
            if bang != -1:
                rs = full[:bang].strip().strip("'")

            if col2 is None:
                # Single cell ref
                v = self._values.get(self._norm(rs + "!" + col1 + row1), 0)
                if v is None:               return "0"
                if isinstance(v, bool):     return "True" if v else "False"
                if isinstance(v, (int, float)): return repr(float(v))
                if isinstance(v, str):
                    if v.startswith("#"):   return "float('nan')"
                    try:                    return repr(float(v))
                    except:                 return repr(v)
                return repr(v)
            else:
                # BUG FIX: Range ref A1:B3 - collect all cell values into a list
                col2 = col2.upper()
                c1, c2 = _col_to_idx(col1), _col_to_idx(col2)
                r1, r2 = int(row1), int(row2)
                if c1 > c2: c1, c2 = c2, c1
                if r1 > r2: r1, r2 = r2, r1
                vals = []
                for r in range(r1, min(r2 + 1, r1 + 10000)):  # cap at 10000 rows
                    for c in range(c1, min(c2 + 1, c1 + 100)):  # cap at 100 cols
                        addr = self._norm(rs + "!" + _idx_to_col(c) + str(r))
                        v = self._values.get(addr, 0)
                        if v is None: v = 0
                        try: vals.append(float(v))
                        except: vals.append(0.0)
                return repr(vals)

        # BUG FIX: regex now captures optional range endpoint (col2, row2)
        # FIX: require ! after unquoted sheet names so multi-letter columns (AA, AB, ...)
        # aren't eaten as sheet names. Group indices shifted +1 vs old pattern.
        # _RANGE_RE is compiled ONCE at module level — NOT per formula.
        expr = _RANGE_RE.sub(sub_ref, formula)

        def sub_fn(m):
            name = m.group(1).upper()
            fn = _REGISTRY.get(name) or _REGISTRY.get(name.replace(".", "_"))
            if fn is None:
                return m.group(0)
            tok = "__fn_" + name.replace(".", "_") + "__"
            self._fn_locals[tok] = fn
            return tok + "("

        expr = _FN_RE.sub(sub_fn, expr)

        # Fix Excel vs Python operator differences
        # ^ is XOR in Python, but exponentiation in Excel
        expr = expr.replace("^", "**")
        # #REF! is invalid syntax in Python
        expr = expr.replace("#REF!", "float('nan')")

        return expr

    def _run(self, expr):
        env = {
            "__builtins__": {}, "True": True, "False": False,
            "nan": float("nan"), "inf": float("inf"),
            "abs": abs, "max": max, "min": min, "round": round,
            "sum": sum, "len": len, "list": list, "range": range,
        }
        for k in dir(math):
            if not k.startswith("_"):
                env[k] = getattr(math, k)
        env.update(self._fn_locals)
        try:
            return eval(expr, env)
        except Exception as e:
            _log_run_fail(expr, e)
            return float("nan")

    @staticmethod
    def _norm(addr):
        # FIX 9: always strip $ so Sheet1!$B$4 == Sheet1!B4
        if "!" not in addr:
            return addr.replace("$", "").upper()
        sheet, ref = addr.rsplit("!", 1)
        sheet = sheet.strip().strip("'")
        ref   = ref.replace("$", "").upper()
        return ("'" + sheet + "'!" + ref) if " " in sheet else (sheet + "!" + ref)

    # FIX 10+11: to_file / from_file so bridge cache logic works unchanged
    def to_file(self, base_name, file_types=("pkl",)):
        if "pkl" in file_types:
            pkl = (base_name if base_name.endswith(".pkl") else base_name + ".pkl")
            try:
                with open(pkl, "wb") as f:
                    pickle.dump({"filename": self._filename}, f)
            except Exception:
                pass

    def trim_graph(self, input_addrs=None, output_addrs=None):
        """Stub: C++ backend loads fast enough that subgraph pruning is
        not needed. The wrapper calls this; we accept and no-op."""
        pass

    @classmethod
    def from_file(cls, path):
        pkl = path if path.endswith(".pkl") else path + ".pkl"
        try:
            with open(pkl, "rb") as f:
                data = pickle.load(f)
            fn = data.get("filename", "")
            if fn and pathlib.Path(fn).exists():
                return cls(fn)
        except Exception:
            pass
        raise FileNotFoundError("FastExcelCompiler.from_file: cannot reload " + path)


ExcelCompiler = FastExcelCompiler


# ---------------------------------------------------------------------------
# Diagnostic logging — writes to %TEMP% so user can inspect after a run
# ---------------------------------------------------------------------------
_eval_fail_logged = 0
_MAX_EVAL_FAIL_LOG = 20


def _log_eval_fail(addr, formula, exc):
    global _eval_fail_logged
    _eval_fail_logged += 1
    if _eval_fail_logged > _MAX_EVAL_FAIL_LOG:
        return
    try:
        import os as _os
        log = _os.path.join(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")),
                            "fc_eval_fails.log")
        mode = "a" if _eval_fail_logged > 1 else "w"
        with open(log, mode, encoding="utf-8") as fh:
            fh.write(f"[{addr}] {type(exc).__name__}: {exc}\n")
            fh.write(f"  formula: {formula[:200]}\n")
    except Exception:
        pass


_run_fail_logged = 0
_MAX_RUN_FAIL_LOG = 30


def _log_run_fail(expr, exc):
    global _run_fail_logged
    _run_fail_logged += 1
    if _run_fail_logged > _MAX_RUN_FAIL_LOG:
        return
    try:
        import os as _os
        log = _os.path.join(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")),
                            "fc_run_fails.log")
        mode = "a" if _run_fail_logged > 1 else "w"
        with open(log, mode, encoding="utf-8") as fh:
            fh.write(f"{type(exc).__name__}: {exc}\n")
            fh.write(f"  expr: {expr[:300]}\n")
    except Exception:
        pass