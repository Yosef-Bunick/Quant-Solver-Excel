"""
_launcher.py — Entry point for PyInstaller-built FastSolver.exe.
"""

import sys
from pathlib import Path

HERE = Path(__file__).parent.resolve()
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# PyInstaller's frozen importer sometimes injects the path to a bundled
# .pyd as argv[1] when the launcher script imports a Cython module that
# matches a --hidden-import. Strip it so the real CLI args shift back.
# Detect by suffix: any argv entry ending in .pyd that points into
# _internal/ is not a user argument.
_filtered = [sys.argv[0]]
for a in sys.argv[1:]:
    al = a.lower()
    if al.endswith(".pyd") or al.endswith(".dll"):
        continue
    _filtered.append(a)
sys.argv = _filtered

if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--monitor":
        import bridge_07
        bridge_07.monitor(sys.argv[2])
        sys.exit(0)
    if len(sys.argv) < 2:
        print("Usage: FastSolver.exe <run_dir>")
        print("       FastSolver.exe --monitor <run_dir>")
        input("Press ENTER to close.")
        sys.exit(1)
    import bridge_07
    bridge_07.main(sys.argv[1])