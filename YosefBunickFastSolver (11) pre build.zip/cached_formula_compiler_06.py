"""
cached_formula_compiler.py — Phase 2 speedup wrapper.

Wraps a pycel ExcelCompiler and pre-compiles every formula's translated
expression into a Python code object ONCE at startup. Subsequent
evaluate() calls execute the cached bytecode directly — no regex
rewriting per call, no eval(str) re-parsing.

Plug-in replacement: bridge code that calls excel.set_value() and
excel.evaluate() works unchanged.

Usage in 07_fastsolver_bridge.py:
    from cached_formula_compiler import wrap_compiler
    excel = wrap_compiler(excel)   # right after _load_excel_cached

Speedup: 3-5x on the solve phase by eliminating per-call regex + parse.
"""

from __future__ import annotations
import re
import math
import time
from collections import deque

# Regex patterns — run ONCE per formula at compile time, not per eval.
_RANGE_RE = re.compile(
    r"(?:'(?:[^']|'')*'!|([A-Za-z_]\w*)!)?\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6})"
    r"(?::\$?([A-Z]{1,3})\$?([1-9][0-9]{0,6}))?",
    re.IGNORECASE,
)
_FN_RE = re.compile(r"\b([A-Z][A-Z0-9_.]*)\s*\(", re.IGNORECASE)


def _col_to_idx(col):
    v = 0
    for c in col:
        v = v * 26 + (ord(c.upper()) - ord('A') + 1)
    return v


def _idx_to_col(idx):
    s = ""
    while idx > 0:
        s = chr(ord('A') + (idx - 1) % 26) + s
        idx = (idx - 1) // 26
    return s


def _norm_addr(addr):
    """Match pycel's address normalization: strip $, uppercase, quote sheets with spaces."""
    if "!" not in addr:
        return addr.replace("$", "").upper()
    sheet, ref = addr.rsplit("!", 1)
    sheet = sheet.strip().strip("'")
    ref = ref.replace("$", "").upper()
    return ("'" + sheet + "'!" + ref) if " " in sheet else (sheet + "!" + ref)


class _CellProxy:
    """Thin proxy so cell_map.get(addr).formula and .value still work."""
    __slots__ = ("formula", "_wrapper", "_addr")

    def __init__(self, wrapper, addr, formula, value):
        self._wrapper = wrapper
        self._addr = addr
        self.formula = formula
        self.value = value

    @property
    def value(self):
        return self._wrapper.evaluate(self._addr)

    @value.setter
    def value(self, v):
        self._wrapper.set_value(self._addr, v)


class _CellMapProxy:
    """Exposes dict-like .get(addr) that returns _CellProxy objects."""
    def __init__(self, wrapper, pycel_cell_map):
        self._wrapper = wrapper
        self._pycel_map = pycel_cell_map

    def get(self, addr, default=None):
        a = _norm_addr(addr)
        # Check our compiled cache first
        if a in self._wrapper._compiled:
            _, _, ftext = self._wrapper._compiled[a]
            return _CellProxy(self._wrapper, a, ftext, self._wrapper._values.get(a))
        # Fall back to pycel
        c = self._pycel_map.get(addr)
        if c is not None:
            return _CellProxy(self._wrapper, a,
                              getattr(c, 'formula', None),
                              self._wrapper._values.get(a))
        return default

    def __len__(self):
        return len(self._wrapper._compiled)

    def keys(self):
        return self._wrapper._compiled.keys()

    def __contains__(self, addr):
        return _norm_addr(addr) in self._wrapper._compiled

    def __iter__(self):
        return iter(self._wrapper._compiled)


class CachedFormulaCompiler:
    """Wraps a pycel ExcelCompiler with pre-compiled formula bytecode."""

    def __init__(self, pycel_excel, function_registry=None, log_fn=None):
        self._pycel = pycel_excel
        self._fns = dict(function_registry or {})
        self._log = log_fn or (lambda s: None)

        # Per-formula compiled state:
        #   _compiled[addr] = (code_object, refs_list, formula_text)
        self._compiled = {}

        # Live cell value cache
        self._values = {}

        # Dependency graph: rdeps[cell] = list of formula cells that depend on it
        self._rdeps = {}

        # Topological order (formula cells in evaluation order)
        self._topo_formula = []

        # Set of formula addresses
        self._formula_addrs = set()

        # Dirty set — formula cells whose value is stale
        self._dirty = set()

        # Expose cell_map so bridge code works
        self.cell_map = _CellMapProxy(self, pycel_excel.cell_map)

        # Forward name_maps
        self._fastsolver_name_maps = getattr(pycel_excel, '_fastsolver_name_maps', None)

        self._build_cache()

    # ------------------------------------------------------------------
    # Build the bytecode cache from the pycel graph
    # ------------------------------------------------------------------

    def _build_cache(self):
        """Walk pycel's graph, pre-compile every formula into bytecode."""
        t0 = time.time()
        excel = self._pycel

        try:
            all_addrs = list(excel.cell_map.keys()) if hasattr(excel.cell_map, 'keys') else []
        except Exception:
            self._log("CachedFormulaCompiler: pycel cell_map unavailable; falling back to pycel")
            self._compiled = {}
            return

        if not all_addrs:
            self._log("CachedFormulaCompiler: empty cell_map; falling back to pycel")
            return

        n_formulas = 0
        n_errors = 0
        # Reset state for rebuild
        self._compiled.clear()
        self._values.clear()
        self._rdeps.clear()
        self._formula_addrs.clear()

        for addr in all_addrs:
            try:
                cell = excel.cell_map.get(addr)
            except Exception:
                continue
            if cell is None:
                continue

            a = _norm_addr(addr)

            # Snapshot current value  (use normalized key!)
            try:
                v = excel.evaluate(addr)
                self._values[a] = v
            except Exception:
                self._values[a] = 0.0

            formula = getattr(cell, 'formula', None)
            if formula is None or str(formula).strip() in ('', '=', 'None'):
                continue

            ftext = str(formula).lstrip("=").strip()
            if not ftext:
                continue

            self._formula_addrs.add(a)

            try:
                code_obj, refs = self._compile_formula(ftext, a)
                self._compiled[a] = (code_obj, refs, ftext)
                for r in refs:
                    self._rdeps.setdefault(r, []).append(a)
                n_formulas += 1
            except Exception as _e:
                n_errors += 1
                self._compiled[a] = (None, [], ftext)
                # DIAGNOSTIC: log compile failures
                try:
                    import os as _os, tempfile as _tf
                    _log = _os.path.join(_tf.gettempdir(), "ast_compile_fails.log")
                    if not hasattr(self, '_compile_fail_count'):
                        self._compile_fail_count = 0
                        try: open(_log, 'w').close()
                        except Exception: pass
                    if self._compile_fail_count < 50:
                        with open(_log, 'a', encoding='utf-8') as _fh:
                            _fh.write(f"COMPILE FAIL [{a}]\n")
                            _fh.write(f"  formula: {ftext[:250]}\n")
                            _fh.write(f"  error:   {type(_e).__name__}: {_e}\n\n")
                        self._compile_fail_count += 1
                except Exception: pass
                self._compiled[a] = (None, [], ftext)

        self._topo_formula = self._build_topo_order()

        elapsed = time.time() - t0
        self._log(f"CachedFormulaCompiler: compiled {n_formulas} formulas "
                  f"({n_errors} fell back to pycel) in {elapsed:.2f}s")

    def _compile_formula(self, ftext, addr):
        """Translate one Excel formula into Python bytecode.

        Returns (code_obj, refs_list).
        """
        sheet = addr.split("!")[0].strip("'") if "!" in addr else "Sheet1"
        refs_collected = []

        def sub_ref(m):
            full = m.group(0)
            col1, row1 = m.group(2).upper(), m.group(3)
            col2, row2 = m.group(4), m.group(5)
            rs = sheet
            bang = full.find("!")
            if bang != -1:
                rs = full[:bang].strip().strip("'")

            if col2 is None:
                ref_addr = _norm_addr(rs + "!" + col1 + row1)
                refs_collected.append(ref_addr)
                return f"_v.get({ref_addr!r},0)"
            else:
                # Range ref A1:B3 — expand to list of _v lookups
                col2u = col2.upper()
                c1, c2 = _col_to_idx(col1), _col_to_idx(col2u)
                r1, r2 = int(row1), int(row2)
                if c1 > c2: c1, c2 = c2, c1
                if r1 > r2: r1, r2 = r2, r1
                cells = []
                for r in range(r1, min(r2 + 1, r1 + 10000)):
                    for c in range(c1, min(c2 + 1, c1 + 100)):
                        ra = _norm_addr(rs + "!" + _idx_to_col(c) + str(r))
                        refs_collected.append(ra)
                        cells.append(f"_v.get({ra!r},0)")
                return "[" + ",".join(cells) + "]"

        expr = _RANGE_RE.sub(sub_ref, ftext)

        def sub_fn(m):
            name = m.group(1).upper()
            if name in self._fns:
                return f"_fns[{name!r}]("
            alt = name.replace(".", "_")
            if alt in self._fns:
                return f"_fns[{alt!r}]("
            # Keep original — will be resolved from math/__builtins__ in env
            return m.group(0)

        expr = _FN_RE.sub(sub_fn, expr)

        # Translate Excel operators to Python
        expr = expr.replace("^", "**")          # power
        expr = expr.replace("<>", "!=")         # not-equal (before = rewrite)
        # Excel '=' is equality, Python needs '==' — but don't touch ==, !=, <=, >=
        import re as _re
        expr = _re.sub(r'(?<![=!<>])=(?!=)', '==', expr)

        # Compile into code object
        code_obj = compile(expr, f"<formula:{addr}>", "eval")
        return code_obj, refs_collected

    def _build_topo_order(self):
        """Kahn's algorithm on formula-only dependency graph."""
        in_deg = {f: 0 for f in self._formula_addrs}
        for f in self._formula_addrs:
            _, refs, _ = self._compiled.get(f, (None, [], ""))
            for r in refs:
                if r in self._formula_addrs:
                    in_deg[f] += 1

        q = deque([f for f, d in in_deg.items() if d == 0])
        order = []
        while q:
            f = q.popleft()
            order.append(f)
            for downstream in self._rdeps.get(f, []):
                if downstream in in_deg:
                    in_deg[downstream] -= 1
                    if in_deg[downstream] == 0:
                        q.append(downstream)
        return order

    # ------------------------------------------------------------------
    # Public API (matches pycel ExcelCompiler)
    # ------------------------------------------------------------------

    def set_value(self, addr, value):
        """Write a cell value; mark dependents dirty."""
        a = _norm_addr(addr)
        v = float(value) if value is not None else 0.0
        self._values[a] = v
        # Propagate to pycel so fallback evaluate() sees current values
        try:
            self._pycel.set_value(addr, v)
        except Exception:
            pass
        self._mark_dirty(a)

    def evaluate(self, addr):
        """Read a cell value, flushing dirty formulas first."""
        if not self._compiled:
            return self._pycel.evaluate(addr)
        a = _norm_addr(addr)
        if self._dirty:
            self._flush_dirty()
        v = self._values.get(a)
        if v is None and a in self._formula_addrs:
            return 0.0
        return v

    def trim_graph(self, input_addrs=None, output_addrs=None):
        """Delegate to pycel's trim_graph, then rebuild cache from trimmed graph."""
        self._pycel.trim_graph(input_addrs=input_addrs, output_addrs=output_addrs)
        self._build_cache()

    def _mark_dirty(self, addr):
        stack = [addr]
        while stack:
            a = stack.pop()
            if a not in self._dirty:
                self._dirty.add(a)
                for dep in self._rdeps.get(a, ()):
                    stack.append(dep)

    def _flush_dirty(self):
        """Recompute dirty formula cells in topo order."""
        # Build eval env once per flush
        env = {
            "__builtins__": {}, "True": True, "False": False, "TRUE": True, "FALSE": False,
            "abs": abs, "ABS": abs,
            "max": max, "MAX": max,
            "min": min, "MIN": min,
            "round": round, "ROUND": round,
            "sum": sum, "SUM": sum,
            "len": len, "LEN": len,
            "_v": self._values,
            "_fns": self._fns,
        }
        # Add math functions with both cases
        for k in ("sqrt", "exp", "log", "log10", "sin", "cos", "tan",
                  "pi", "e", "floor", "ceil", "fabs", "pow",
                  "log2", "log1p", "expm1", "hypot", "atan", "atan2",
                  "asin", "acos", "sinh", "cosh", "tanh",
                  "degrees", "radians", "erf", "erfc", "gamma", "lgamma"):
            v = getattr(math, k, 0.0)
            env[k] = v
            env[k.upper()] = v

        for f in self._topo_formula:
            if f not in self._dirty:
                continue
            code_obj, refs, ftext = self._compiled.get(f, (None, [], ""))
            if code_obj is None:
                # Fallback to pycel for this formula
                try:
                    self._values[f] = self._pycel.evaluate(f)
                except Exception:
                    self._values[f] = float("nan")
                continue
            try:
                self._values[f] = eval(code_obj, env)
            except Exception as _e:
                # DIAGNOSTIC (commented): log eval failures to %TEMP%\ast_eval_fails.log
                # try:
                #     import os as _os, tempfile as _tf
                #     _log = _os.path.join(_tf.gettempdir(), "ast_eval_fails.log")
                #     if not hasattr(self, '_fail_count'):
                #         self._fail_count = 0
                #         try: open(_log, 'w').close()
                #         except Exception: pass
                #     if self._fail_count < 20:
                #         with open(_log, 'a', encoding='utf-8') as _fh:
                #             _fh.write(f"FAIL [{f}]\n")
                #             _fh.write(f"  formula: {ftext[:200]}\n")
                #             _fh.write(f"  error:   {type(_e).__name__}: {_e}\n\n")
                #         self._fail_count += 1
                # except Exception: pass
                # Fallback to pycel for this formula
                try:
                    self._values[f] = self._pycel.evaluate(f)
                except Exception:
                    self._values[f] = float("nan")

        self._dirty.clear()

        # DIAGNOSTIC (commented): dump formula refs/values to %TEMP%\ast_translated.log
        # try:
        #     import os as _os, tempfile as _tf
        #     _log = _os.path.join(_tf.gettempdir(), "ast_translated.log")
        #     if not hasattr(self, '_tcount'):
        #         self._tcount = 0
        #         try: open(_log, 'w').close()
        #         except Exception: pass
        #     if self._tcount < 8:
        #         for f in self._topo_formula:
        #             if self._tcount >= 8: break
        #             if f not in self._compiled: continue
        #             _, refs, ftext = self._compiled[f]
        #             try:
        #                 with open(_log, 'a', encoding='utf-8') as _fh:
        #                     _fh.write(f"FORMULA [{f}]\n")
        #                     _fh.write(f"  raw:    {ftext[:250]}\n")
        #                     _fh.write(f"  refs:   {refs[:30]}\n")
        #                     _fh.write(f"  result: {self._values.get(f)}\n")
        #                     if refs:
        #                         _fh.write(f"  ref_vals: { {r: self._values.get(r) for r in refs[:15]} }\n")
        #                     _fh.write("\n")
        #                 self._tcount += 1
        #             except Exception: pass
        # except Exception: pass

    # ------------------------------------------------------------------
    # Cache delegation (for pycel pickle compatibility)
    # ------------------------------------------------------------------

    def to_file(self, *args, **kwargs):
        return self._pycel.to_file(*args, **kwargs)

    @classmethod
    def from_file(cls, *args, **kwargs):
        raise NotImplementedError("Use wrap_compiler() on a pycel-loaded instance")


def wrap_compiler(pycel_excel, log_fn=None):
    """One-line wrapper: pass a pycel ExcelCompiler, get a cached one back."""
    try:
        from excel_functions_80_09 import EXACT_REGISTRY_80 as registry
    except ImportError:
        try:
            from excel_functions_15_08 import EXACT_REGISTRY as registry
        except ImportError:
            registry = {}

    try:
        wrapped = CachedFormulaCompiler(pycel_excel, registry, log_fn)
        if not wrapped._compiled:
            if log_fn:
                log_fn("CachedFormulaCompiler: 0 formulas compiled; using pycel directly")
            return pycel_excel
        return wrapped
    except Exception as e:
        if log_fn:
            log_fn(f"CachedFormulaCompiler wrap failed ({e}); using pycel directly")
        return pycel_excel
