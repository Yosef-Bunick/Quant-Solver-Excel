"""
setup_cython.py — Compile FastSolver algorithm modules to native .pyd binaries.

Usage:
    python setup_cython.py build_ext --inplace

Requires: pip install cython setuptools

Compiles:
  cached_formula_compiler_06.py→ cached_formula_compiler_06.*.pyd
  bridge_07.py → bridge_07.*.pyd
  excel_functions_15_08.py → excel_functions_15_08.*.pyd
  excel_functions_80_09.py → excel_functions_80_09.*.pyd

After building, rebuild the .exe with 11_build_exe.py.
"""

import sys
from pathlib import Path

HERE = Path(__file__).parent.resolve()

try:
    from Cython.Build import cythonize
    from setuptools import setup, Extension
except ImportError as e:
    print(f"MISSING: {e}")
    print("Fix: pip install cython setuptools")
    sys.exit(1)


SOURCES = [
    "cached_formula_compiler_06.py",
    "bridge_07.py",
    "excel_functions_15_08.py",
    "excel_functions_80_09.py",
]


def main():
    extensions = []
    for src in SOURCES:
        src_path = HERE / src
        if not src_path.exists():
            print(f"MISSING source: {src_path}")
            sys.exit(1)
        name = src_path.stem
        print(f"  {name}  ←  {src}")
        extensions.append(Extension(name, [str(src_path)]))

    print(f"\nCompiling {len(extensions)} modules ...\n")

    setup(
        name="fastsolver_cython",
        ext_modules=cythonize(
            extensions,
            compiler_directives={
                "language_level": 3,
                "boundscheck": False,
                "wraparound": False,
            },
        ),
        script_args=["build_ext", "--inplace"],
    )

    pyd_files = sorted(HERE.glob("*.pyd"))
    print(f"\nDone. {len(pyd_files)} .pyd files built:")
    for pf in pyd_files:
        size_kb = pf.stat().st_size / 1024
        print(f"  {pf.name}  ({size_kb:.0f} KB)")

    print("\nNext:  python 11_build_exe.py")


if __name__ == "__main__":
    main()
